---
name: reel-post-kit
description: Get a finished Reel ready to post on Instagram - a cover thumbnail in the reel's style (1080x1920, safe for the 4:5 profile grid), caption options, the comment-keyword auto-DM, public comment replies and a pinned comment. Use when the user says "thumbnail", "cover", "caption", "DM text", "make it ready to post", or has a reel in Exports and wants to publish it.
---

# Reel post kit

Everything the user needs to publish one reel, written to `Exports/<reel name>-post.md` plus the thumbnail image. Nothing is posted for them: they paste it.

## 1. Thumbnail

- Size **1080x1920**, in the reel's own style (same colours, fonts, badge) so it looks like the video.
- Instagram's profile grid shows only the middle **1080x1350** (from y 285 to y 1635). Keep the hook, the badge and the main object inside that area; check it by cropping a preview.
- Content: the reel's hook as a big headline (2 lines max, one highlighted word), the main visual from the hook scene, and one small line of payoff (for example "5 steps").
- Readable at phone-grid size: big text, high contrast, little else.
- Build it as HTML or a Remotion still, render it, look at it yourself, fix overflow or overlap, then show the user both the full image and the grid crop.

## 2. Caption options (give 3)

The reel already hooks people, so the caption's first line is the **ask**, said plainly, inside the first 125 characters (what shows before "more").

- **One ask only**: comment a single keyword, the same word the video says. No second ask.
- Then 2-6 short paragraphs: what they get, the steps or the proof, and the phrases people would search for ("AI video editor", the tool names, the language), written as normal sentences.
- No links in captions (they don't click). Up to **5** specific hashtags on the last line, or none. No #viral / #fyp.
- Emoji as punctuation, not decoration. No em dashes, no AI filler words.
- Write in the user's language mix, the way they talk in the video.

## 3. Comment-keyword auto-DM (give 3)

For people who commented the keyword:

1. **Deliver first**, in the first message, with no conditions. Don't make it depend on following.
2. One line on how to use it.
3. One easy question they can answer in a few words (it starts a real conversation; it's optional for them).

Add the button text and link if the user's DM tool supports buttons. Use only automation the platform allows for keyword replies (Instagram's own tools or an approved partner); never send DMs to people who didn't comment.

## 4. Comment replies and pin

- 3 short public replies to rotate ("Sent, check your inbox", "Check message requests too", ...).
- 1 pinned comment that repeats the keyword ask.

## Finish

Print the receipt: the thumbnail paths, which caption you recommend and why, characters used before the cut, number of hashtags, and the keyword. Remind the user to set up the keyword automation **before** posting, and to test it from a second account.
