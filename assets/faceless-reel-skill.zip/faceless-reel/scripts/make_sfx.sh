#!/usr/bin/env bash
# Creates the reel sound effects with FFmpeg (synthesised, no licensing needed).
# Usage: bash make_sfx.sh "<output folder>"
set -e
D="${1:-sfx}"
mkdir -p "$D"
Q="-hide_banner -loglevel error -y"
ffmpeg $Q -f lavfi -i "aevalsrc='(random(0)*2-1)*pow(sin(PI*t/0.45),2)':d=0.45:s=44100" -af "highpass=f=400,lowpass=f=3000" "$D/whoosh.wav"
ffmpeg $Q -f lavfi -i "aevalsrc='0.6*sin(2*PI*(500*t+40*sin(2*PI*11*t)/(2*PI*11)*60))*(1-t/0.4)+0.25*(random(0)*2-1)*(1-t/0.4)':d=0.4:s=44100" -af "lowpass=f=2500,highpass=f=150" "$D/scratch.wav"
ffmpeg $Q -f lavfi -i "aevalsrc='(0.35*sgn(sin(2*PI*98*t))+0.3*sgn(sin(2*PI*131*t)))*min(1,t/0.01)*min(1,(0.55-t)/0.08)':d=0.55:s=44100" -af "lowpass=f=1800" "$D/buzzer.wav"
ffmpeg $Q -f lavfi -i "aevalsrc='(0.4*sin(2*PI*(180*t+260*t*t))+0.3*(random(0)*2-1))*pow(t/1.6,2)*min(1,(1.6-t)/0.05)':d=1.6:s=44100" -af "lowpass=f=4000,highpass=f=120" "$D/riser.wav"
echo "sfx written to $D"
