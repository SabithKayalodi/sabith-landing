---
name: faceless-reel
description: Make a faceless Instagram Reel (1080x1920, 30 fps) from a voiceover file and one photo, following the user's approved brand sheet - scenes timed to the voice, word-by-word captions, a round photo badge with the handle, drawn motion graphics, music and sound effects, built in Remotion and finished with FFmpeg. Use when the user puts a voice file (and a photo) in Raw Footage and asks for a reel, short video or "make it", or wants an existing reel re-timed, fixed or re-rendered.
---

# Faceless reel from voice + photo

The user does not appear on camera. Their voice carries the reel, their photo sits in a small round badge, and everything else is motion graphics drawn in code. Work inside their **AI Video Editor** folder: inputs in `Raw Footage`, style in the approved brand sheet, results in `Exports`.

## Before you start

- **Brand sheet**: find the one the user approved (usually made from their reference videos). Follow its colours, fonts, caption style, pacing and motion rules. If there is none, use the defaults at the bottom and say so.
- **Inputs**: a voice file (mp3/wav, own recording or AI voice), one photo, and ideally the script text or an `.srt`. Ask only if the voice or the photo is missing.
- **Tools**: Remotion, FFmpeg/ffprobe, whisper.cpp. If one is missing, install it first and test it.
- Ask for the user's **handle** once (for the badge) if you don't know it.

## Workflow

1. **Read everything.** Script, SRT, brand sheet. `ffprobe` the voice for its length.
2. **Get the words with times.**
   - If an SRT is given, use it. Otherwise run whisper.cpp to make one; use a large model for non-English speech and set the language explicitly.
   - If the user gave the script text, keep **their spellings** in the captions; use whisper only for timing. Never "correct" their words.
3. **Plan the scenes from the voice.**
   - Find speech onsets with `ffmpeg -i voice.mp3 -af silencedetect=noise=-35dB:d=0.12 -f null -` (each `silence_end` is a word onset). Use a shorter `d` (0.08) if you need a split inside a long line.
   - One idea per scene. Each scene starts within **100 ms** of its first word. **No scene longer than 4 s**; split long lines at an internal breath. Scene 1 starts at frame 0.
   - Write the plan to a timeline JSON (key, first words, onset, start frame, end frame) and build everything from it.
4. **Build the composition in Remotion** (1080x1920, 30 fps).
   - Layout: photo badge top-left (round, accent ring, handle beside it, a glow that follows the voice loudness); headline in the upper part (max 2 lines, about 6 words, one highlighted word); the visual in the middle; captions in the lower-middle (2-5 words at a time, current word highlighted, upcoming words dimmed).
   - Keep the **right 12%** and the **bottom 18%** of the frame free of text: Instagram's buttons and caption cover them.
   - Visuals: simple flat drawings in code (devices, folders, cards, icons, terminals with made-up demo names). No real company logos, no copied app screens, no stock photos unless the user asks.
   - Motion: something moves from the first frame of every scene; pop-ins with a slight overshoot; a short wipe between topics (continuations of the same idea skip it); numbers count up; typing for commands.
   - **Frame 0 is the cover**: it must already show the hook headline, the badge and the main object.
5. **Preview before rendering.** Render one still per scene (a few frames after each cut, plus frame 0), tile them into contact sheets, check them yourself for overlaps and unreadable text, then show the user and **wait for approval**. Full renders take minutes; stills take seconds.
6. **Render and mix.** Render the picture silent, then mix with FFmpeg:
   - Voice untouched and always the loudest thing.
   - Music bed (royalty-free or the user's own licence) about 20 dB under the voice, short fade in and out.
   - Sound effects: a soft whoosh on scene changes (about -17 dB), optional scratch/buzzer on beats the script calls for, a riser into the call to action. `scripts/make_sfx.sh <folder>` creates synthesised ones with no licensing issues.
   - Target about -14 to -15 LUFS integrated, peaks below -1 dBFS (`ffmpeg -i out.mp4 -af ebur128=peak=true -f null -`).
7. **Verify and report.** Check each cut lands on its planned frame and within 100 ms of its word, the voice is in sync, and frame 0 works as a cover. Save to `Exports` with a **new file name** (never overwrite another reel). Tell the user the length, the worst timing drift, the loudness, any scene you had to split, and that you have not watched it with sound if you haven't.

## Default style (only when there is no brand sheet)

Light off-white background with one soft accent glow, one accent colour for highlights (about 10% of the frame), dark text, a bold sans-serif headline font, a monospace font for small labels, red only for "wrong" and green only for "done".

## Changes after the first version

Re-render stills for the scenes that changed, show them, then render. Keep each version as its own file so the user can compare.
